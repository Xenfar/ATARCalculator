﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CsvHelper;
using System.IO;
using System.Globalization;

namespace TechSac
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Subject[] subjects;
        Range[] ranges;
        Scale[] scales;
        public MainWindow()
        {
            InitializeComponent();

            //Read csv to array of custom class Subject
            subjects = ReadCsv();
            //Give dropdown boxes subject array as inputs
            List<string> subjectNames = new List<string>();
            for (int i = 0; i < subjects.Length; i++)
            {
                subjectNames.Add(subjects[i].SubjectName);
            }
            firstDropdownBox.ItemsSource = subjectNames;
            secondDropdownBox.ItemsSource = subjectNames;
            thirdDropdownBox.ItemsSource = subjectNames;
            fourthDropdownBox.ItemsSource = subjectNames;


        }

        private void calculateButton_Click(object sender, RoutedEventArgs e)
        {
            int aggregate = 0;
            int firstScore = 0;
            int secondScore = 0;
            int thirdScore = 0;
            int fourthScore = 0;
            //Use try-catch to tell user if input is not an integer
            try
            {
                //Parse strings to integers
                //Check if scores have been scaled, if not use default score otherwise use scaled scores for aggregate
                if (scaledScoreLabel1.Content.ToString() == "")
                {
                    firstScore = Int32.Parse(firstScoreInput.Text.ToString());
                    secondScore = Int32.Parse(secondScoreInput.Text.ToString());
                    thirdScore = Int32.Parse(thirdScoreInput.Text.ToString());
                    fourthScore = Int32.Parse(fourthScoreInput.Text.ToString());
                }
                else
                {
                    firstScore = Int32.Parse(scaledScoreLabel1.Content.ToString());
                    secondScore = Int32.Parse(scaledScoreLabel2.Content.ToString());
                    thirdScore = Int32.Parse(scaledScoreLabel3.Content.ToString());
                    fourthScore = Int32.Parse(scaledScoreLabel4.Content.ToString());
                }

                

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            //Check if inputs are over 50, if so prompt user to change value, otherwise show aggregation of values
            if (firstScore > 50 || secondScore > 50 || thirdScore > 50 || fourthScore > 50)
            {
                warningLabel.Content = "Score must be a number between 0 and 50";
                return;
            }
            else
            {
                warningLabel.Content = "";
                aggregate = firstScore + secondScore + thirdScore + fourthScore;
                aggregateText.Content = "Aggregate: " + aggregate.ToString();


                //Initialise stream reader class with path to csv file, then initialise CsvReader class and input stream reader and culture info
                using (var reader = new StreamReader("atar_range.csv"))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    //Get csv values
                    var records = csv.GetRecords<Range>();
                    //set _subjects array to records values casted to an array
                    ranges = records.ToArray();
                }
                for (int i = 0; i < ranges.Length; i++)
                {
                    if (aggregate >= ranges[i].Aggregate_Minimum_Range && aggregate <= ranges[i].Aggregate_Maximum_Range)
                    {
                        atarText.Content = "ATAR: " + ranges[i].ATAR_Range.ToString();
                    }
                }
            }
        }


        
        private void checkSubjectTypeButton_Click(object sender, RoutedEventArgs e)
        {
            warningLabel.Content = "";
            List<Subject> selectedSubjects = new List<Subject>();
            //Check if uuser has selected 4 subjects, if not prompt user to do so
            if (firstDropdownBox.SelectedItem != null && secondDropdownBox.SelectedItem!= null && thirdDropdownBox.SelectedItem != null && fourthDropdownBox.SelectedItem != null)
            {
                //loop through and check if selected item in dropbox equals current subject name and if so update subject type labels
                for (int i = 0; i < subjects.Length; i++)
                {

                    if (firstDropdownBox.SelectedItem.ToString() == subjects[i].SubjectName)
                    {
                        firstSubjectType.Content = subjects[i].SubjectArea;
                        selectedSubjects.Add(subjects[i]);
                    }
                    if (secondDropdownBox.SelectedItem.ToString() == subjects[i].SubjectName)
                    {
                        secondSubjectType.Content = subjects[i].SubjectArea;
                        selectedSubjects.Add(subjects[i]);
                    }
                    if (thirdDropdownBox.SelectedItem.ToString() == subjects[i].SubjectName)
                    {
                        thirdSubjectType.Content = subjects[i].SubjectArea;
                        selectedSubjects.Add(subjects[i]);
                    }
                    if (fourthDropdownBox.SelectedItem.ToString() == subjects[i].SubjectName)
                    {
                        fourthSubjectType.Content = subjects[i].SubjectArea;
                        selectedSubjects.Add(subjects[i]);
                    }

                }
            }
            else
            {
                warningLabel.Content = "Please select four subjects";
                return;
            }

            //Check if a subject is selected more than once, and if so warn the user, code influenced by https://stackoverflow.com/questions/18547354/c-sharp-linq-find-duplicates-in-list 
            var duplicates = selectedSubjects
            .GroupBy(subject => subject) 
            .Where(subjectList => subjectList.Count() > 1) 
            .Select(subjectList => subjectList.Key); 
            foreach (var duplicate in duplicates)
            {
                warningLabel.Content = "You have selected " + duplicate.SubjectName + " more than once, please select a different subject";
                return;
            }

               

            bool englishSubjectSelected = false;
            //Check if at least one english subject is selected, if not prompt the user to do so
            for (int i = 0; i < selectedSubjects.Count; i++)
            {
                if (selectedSubjects[i].SubjectArea == "English")
                {
                    englishSubjectSelected = true;
                }
            }
            if (englishSubjectSelected == false)
            {
                warningLabel.Content = "You must have at least one english subject selected";
                return;
            }

        }

        public Subject[] ReadCsv()
        {
            //Initialise tempoarary array to write csv values to 
            Subject[] _subjects;
            //Initialise stream reader class with path to csv file, then initialise CsvReader class and input stream reader and culture info
            using (var reader = new StreamReader("VCE_subject_list.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                //Get csv values
                var records = csv.GetRecords<Subject>();
                //set _subjects array to records values casted to an array
                _subjects = records.ToArray();
            }
            //Return csv values
            return _subjects;
        }

        private void ApplyScalingButton_Click(object sender, RoutedEventArgs e)
        {
            //Initialise stream reader class with path to csv file, then initialise CsvReader class and input stream reader and culture info
            using (var reader = new StreamReader("scaling.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                //Get csv values
                var records = csv.GetRecords<Scale>();
                //set _subjects array to records values casted to an array
                scales = records.ToArray();
            }
            //Make sure inputs are integers
            try
            {
                int one = Int32.Parse(firstScoreInput.Text);
                int two = Int32.Parse(firstScoreInput.Text);
                int three = Int32.Parse(firstScoreInput.Text);
                int four = Int32.Parse(firstScoreInput.Text);
            }catch(Exception ex)
            {
                warningLabel.Content = "Score inputs must be in integer format";
                return;
            }
            //Loop through subjects/scales and find if subject name [i] is equivalent to selected subject, if so apply scaling and return value to scaledScoreLabel UI
            if (firstDropdownBox.SelectedItem != null && secondDropdownBox.SelectedItem != null && thirdDropdownBox.SelectedItem != null && fourthDropdownBox.SelectedItem != null )
            {
                if  (firstScoreInput.Text != "" && secondScoreInput.Text != "" && thirdScoreInput.Text != "" && fourthScoreInput.Text != "")
                {
                    for (int i = 0; i < scales.Length; i++)
                    {
                        if (subjects[i].SubjectName == firstDropdownBox.SelectedValue.ToString())
                        {
                            int scaledNumber = 0;
                            if (scales[i].Operation == "+")
                            {
                                scaledNumber = Int32.Parse(firstScoreInput.Text) + scales[i].Scale_Number;
                            }
                            else if (scales[i].Operation == "-")
                            {
                                scaledNumber = Int32.Parse(firstScoreInput.Text) - scales[i].Scale_Number;
                            }

                            scaledScoreLabel1.Content = scaledNumber.ToString();
                        }

                        if (subjects[i].SubjectName == secondDropdownBox.SelectedValue.ToString())
                        {
                            int scaledNumber = 0;
                            if (scales[i].Operation == "+")
                            {
                                scaledNumber = Int32.Parse(secondScoreInput.Text) + scales[i].Scale_Number;
                            }
                            else if (scales[i].Operation == "-")
                            {
                                scaledNumber = Int32.Parse(secondScoreInput.Text) - scales[i].Scale_Number;
                            }

                            scaledScoreLabel2.Content = scaledNumber.ToString();
                        }

                        if (subjects[i].SubjectName == thirdDropdownBox.SelectedValue.ToString())
                        {
                            int scaledNumber = 0;
                            if (scales[i].Operation == "+")
                            {
                                scaledNumber = Int32.Parse(thirdScoreInput.Text) + scales[i].Scale_Number;
                            }
                            else if (scales[i].Operation == "-")
                            {
                                scaledNumber = Int32.Parse(thirdScoreInput.Text) - scales[i].Scale_Number;
                            }

                            scaledScoreLabel3.Content = scaledNumber.ToString();
                        }

                        if (subjects[i].SubjectName == fourthDropdownBox.SelectedValue.ToString())
                        {
                            int scaledNumber = 0;
                            if (scales[i].Operation == "+")
                            {
                                scaledNumber = Int32.Parse(fourthScoreInput.Text) + scales[i].Scale_Number;
                            }
                            else if (scales[i].Operation == "-")
                            {
                                scaledNumber = Int32.Parse(fourthScoreInput.Text) - scales[i].Scale_Number;
                            }

                            scaledScoreLabel4.Content = scaledNumber.ToString();
                        }
                    }
                }
                else
                {
                    warningLabel.Content = "Please input four scores";
                    return;
                }


            }
            else
            {
                warningLabel.Content = "Please select four subjects";
                return;
            }
        }
        //Custom classes to aid in reading csv files
        public class Subject
        {
            public string SubjectCode { get; set; }
            public string SubjectName { get; set; }
            public string SubjectArea { get; set; }
        }
        public class Range
        {
            public int Aggregate_Minimum_Range { get; set; }
            public int Aggregate_Maximum_Range { get; set; }
            public string ATAR_Range { get; set; }
        }
        public class Scale
        {
            public string Subject_Code { get; set; }
            public int Scale_Number { get; set; }
            public string Operation { get; set; }
        }


    }
}
