﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CsvHelper;
using System.IO;
using System.Globalization;

namespace TechSac
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //englishInput.ItemsSource = 
            Subject[] subjects = ReadCsv();
            List<string> englishSubjects = new List<string>();
            List<string> scienceSubjects = new List<string>();
            List<string> digitalTechnologiesSubjects = new List<string>();
            List<string> mathematicsSubjects = new List<string>();
            for (int i = 0; i < subjects.Length; i++)
            {
                if (subjects[i].SubjectArea == "English")
                {
                        englishSubjects.Add(subjects[i].SubjectName);
                    
                }
                if (subjects[i].SubjectArea == "Science")
                {
                        scienceSubjects.Add(subjects[i].SubjectName);

                }
                if (subjects[i].SubjectArea == "Digital Technologies")
                {
                        digitalTechnologiesSubjects.Add(subjects[i].SubjectName);

                }
                if (subjects[i].SubjectArea == "Mathematics")
                {
                        mathematicsSubjects.Add(subjects[i].SubjectName);

                }
            }

            englishInput.ItemsSource = englishSubjects;
            scienceInput.ItemsSource = scienceSubjects;
            digitalTechnologiesInput.ItemsSource = digitalTechnologiesSubjects;
            mathematicsInput.ItemsSource = mathematicsSubjects;

            

        }

        private void calculateButton_Click(object sender, RoutedEventArgs e)
        {
            int englishScore = 0;
            int scienceScore = 0;
            int digitalTechnologiesScore = 0;
            int mathematicsScore = 0;
            try
            {
                englishScore = Int32.Parse(englishScoreInput.Text.ToString());
                scienceScore = Int32.Parse(scienceScoreInput.Text.ToString());
                digitalTechnologiesScore = Int32.Parse(digitalTechnologiesScoreInput.Text.ToString());
                mathematicsScore = Int32.Parse(mathematicsScoreInput.Text.ToString());
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            if (englishScore > 50 || scienceScore > 50 || digitalTechnologiesScore > 50 || mathematicsScore > 50)
            {
                warningLabel.Content = "Score must be a number between 0 and 50";
                return;
            }
            else
            {
                int finalscore = englishScore + scienceScore + digitalTechnologiesScore + mathematicsScore;
                aggregateText.Content = "Aggregate: " + finalscore.ToString();
            }
        }

        private void checkSubjectTypeButton_Click(object sender, RoutedEventArgs e)
        {

        }

        public Subject[] ReadCsv()
        {
            Subject[] _subjects;

            using (var reader = new StreamReader("VCE_subject_list.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var records = csv.GetRecords<Subject>();

                _subjects = records.ToArray();
            }

            return _subjects;
        }
        public class Subject
        {
            public string SubjectCode { get; set; }
            public string SubjectName { get; set; }
            public string SubjectArea { get; set; }
        }
    }
}
